class ChainingHashNode():
    def __init__(self, key=None):
        self.key = key
        self.next = None
