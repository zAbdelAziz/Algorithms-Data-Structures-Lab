class Edge():
    def __init__(self, first_vertex, second_vertex, weight):
        self.first_vertex = first_vertex     # reference to a vertex
        self.second_vertex = second_vertex   # reference to a vertex
        self.weight = weight                 # weight of the edge
