class Vertex():
    def __init__(self, index, name: str):
        self.idx = index   # index at which the vertex has been added
        self.name = name   # name of the vertex
